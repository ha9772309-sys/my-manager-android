package com.example.mymanager

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Task(val id: Long, val title: String, val category: String, val priority: String, val due: String, val done: Boolean)
data class Entry(val id: Long, val title: String, val amount: Double, val income: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MyManagerApp() }
    }
}

private fun loadTasks(ctx: Context): List<Task> = try {
    val a = JSONArray(ctx.getSharedPreferences("mm", 0).getString("tasks", "[]"))
    (0 until a.length()).map { i -> a.getJSONObject(i).let {
        Task(it.getLong("id"), it.getString("title"), it.getString("category"), it.getString("priority"), it.getString("due"), it.getBoolean("done"))
    } }
} catch (_: Exception) { emptyList() }

private fun saveTasks(ctx: Context, tasks: List<Task>) {
    val a = JSONArray()
    tasks.forEach { t -> a.put(JSONObject().put("id",t.id).put("title",t.title).put("category",t.category).put("priority",t.priority).put("due",t.due).put("done",t.done)) }
    ctx.getSharedPreferences("mm", 0).edit().putString("tasks", a.toString()).apply()
}
private fun loadEntries(ctx: Context): List<Entry> = try {
    val a = JSONArray(ctx.getSharedPreferences("mm", 0).getString("entries", "[]"))
    (0 until a.length()).map { i -> a.getJSONObject(i).let { Entry(it.getLong("id"),it.getString("title"),it.getDouble("amount"),it.getBoolean("income")) } }
} catch (_: Exception) { emptyList() }
private fun saveEntries(ctx: Context, entries: List<Entry>) {
    val a = JSONArray()
    entries.forEach { e -> a.put(JSONObject().put("id",e.id).put("title",e.title).put("amount",e.amount).put("income",e.income)) }
    ctx.getSharedPreferences("mm", 0).edit().putString("entries", a.toString()).apply()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyManagerApp() {
    val ctx = LocalContext.current
    var tasks by remember { mutableStateOf(loadTasks(ctx)) }
    var entries by remember { mutableStateOf(loadEntries(ctx)) }
    var urdu by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var showAddTask by remember { mutableStateOf(false) }
    var showAddEntry by remember { mutableStateOf(false) }
    val t: (String, String) -> String = { en, ur -> if (urdu) ur else en }
    val completed = tasks.count { it.done }
    val income = entries.filter { it.income }.sumOf { it.amount }
    val expenses = entries.filter { !it.income }.sumOf { it.amount }

    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF2457C5), secondary = androidx.compose.ui.graphics.Color(0xFF16856B))) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Column { Text("My Manager", fontWeight = FontWeight.Bold); Text(t("Personal + Business","ذاتی اور کاروباری مینیجر"), style = MaterialTheme.typography.labelSmall) } },
                    actions = { TextButton(onClick = { urdu = !urdu }) { Text(if (urdu) "English" else "اردو") } }
                )
            },
            floatingActionButton = {
                if (tab == 1) FloatingActionButton(onClick = { showAddTask = true }) { Icon(Icons.Default.Add, contentDescription = "Add task") }
                if (tab == 2) FloatingActionButton(onClick = { showAddEntry = true }) { Icon(Icons.Default.Add, contentDescription = "Add money entry") }
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text(t("Home","ہوم")) })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.CheckCircle, null) }, label = { Text(t("Tasks","کام")) })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.AccountBalanceWallet, null) }, label = { Text(t("Money","رقم")) })
                }
            }
        ) { padding ->
            when (tab) {
                0 -> HomeScreen(Modifier.padding(padding), t, tasks, completed, income, expenses) { tab = 1 }
                1 -> TasksScreen(Modifier.padding(padding), t, tasks,
                    onToggle = { task -> tasks = tasks.map { if (it.id == task.id) it.copy(done = !it.done) else it }; saveTasks(ctx,tasks) },
                    onDelete = { task -> tasks = tasks.filterNot { it.id == task.id }; saveTasks(ctx,tasks) })
                else -> MoneyScreen(Modifier.padding(padding), t, entries, income, expenses,
                    onDelete = { e -> entries = entries.filterNot { it.id == e.id }; saveEntries(ctx,entries) })
            }
        }
    }
    if (showAddTask) AddTaskDialog(urdu, onDismiss = { showAddTask = false }) { title, category, priority, due ->
        tasks = tasks + Task(System.currentTimeMillis(), title, category, priority, due, false)
        saveTasks(ctx,tasks); showAddTask = false
    }
    if (showAddEntry) AddEntryDialog(urdu, onDismiss = { showAddEntry = false }) { title, amount, isIncome ->
        entries = entries + Entry(System.currentTimeMillis(), title, amount, isIncome)
        saveEntries(ctx,entries); showAddEntry = false
    }
}

@Composable
fun HomeScreen(modifier: Modifier, t: (String,String)->String, tasks: List<Task>, completed: Int, income: Double, expenses: Double, goTasks: ()->Unit) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(t("Your overview","آپ کی روزانہ رپورٹ"), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault()).format(Date()), color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard(t("Total tasks","کل کام"), tasks.size.toString(), Modifier.weight(1f))
            StatCard(t("Completed","مکمل"), completed.toString(), Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard(t("Income (PKR)","آمدن (روپے)"), "%.0f".format(income), Modifier.weight(1f))
            StatCard(t("Expenses (PKR)","اخراجات (روپے)"), "%.0f".format(expenses), Modifier.weight(1f))
        }
        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(t("Today's focus","آج کی ترجیح"), fontWeight = FontWeight.Bold)
                Text(if (tasks.isEmpty()) t("Add your first task to get started.","شروع کرنے کے لیے اپنا پہلا کام شامل کریں۔") else t("${tasks.count { !it.done }} tasks still need attention.","${tasks.count { !it.done }} کام ابھی باقی ہیں۔"))
                Button(onClick = goTasks) { Text(t("Manage tasks","کام دیکھیں")) }
            }
        }
        Text(t("Tip: Keep your tasks small and clear.","مشورہ: اپنے کام مختصر اور واضح رکھیں۔"), style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) { Text(label, style = MaterialTheme.typography.labelMedium); Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) } }
}

@Composable
fun TasksScreen(modifier: Modifier, t: (String,String)->String, tasks: List<Task>, onToggle: (Task)->Unit, onDelete: (Task)->Unit) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text(t("My tasks","میرے کام"), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        if (tasks.isEmpty()) Text(t("No tasks yet. Tap + to add your first task.","ابھی کوئی کام نہیں۔ نیا کام شامل کرنے کے لیے + دبائیں۔"), modifier = Modifier.padding(top=20.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(tasks, key = { it.id }) { task ->
                Card {
                    Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = task.done, onCheckedChange = { onToggle(task) })
                        Column(Modifier.weight(1f)) {
                            Text(task.title, fontWeight = FontWeight.SemiBold)
                            Text("${task.category} • ${task.priority} • ${task.due.ifBlank { "No date" }}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { onDelete(task) }) { Icon(Icons.Default.Delete, contentDescription = "Delete") }
                    }
                }
            }
        }
    }
}

@Composable
fun MoneyScreen(modifier: Modifier, t: (String,String)->String, entries: List<Entry>, income: Double, expenses: Double, onDelete: (Entry)->Unit) {
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text(t("Money manager","رقم کا حساب"), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(t("All amounts are in Pakistani rupees (PKR).","تمام رقم پاکستانی روپے میں ہے۔"), style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(12.dp))
        Card { Column(Modifier.padding(16.dp)) {
            Text(t("Balance","بقیہ رقم"), style = MaterialTheme.typography.labelLarge)
            Text("PKR %.2f".format(income-expenses), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("${t("Income","آمدن")}: %.2f   ${t("Expenses","اخراجات")}: %.2f".format(income,expenses), style = MaterialTheme.typography.bodySmall)
        } }
        Spacer(Modifier.height(12.dp))
        if (entries.isEmpty()) Text(t("No entries yet. Tap + to record income or an expense.","ابھی کوئی اندراج نہیں۔ آمدن یا خرچ درج کرنے کے لیے + دبائیں۔"))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(entries.reversed(), key = { it.id }) { e ->
                Card { Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(e.title, fontWeight = FontWeight.SemiBold); Text(if(e.income) t("Income","آمدن") else t("Expense","خرچ"), style = MaterialTheme.typography.labelSmall) }
                    Text((if(e.income) "+" else "-") + " PKR %.2f".format(e.amount), color = if(e.income) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                    IconButton(onClick = { onDelete(e) }) { Icon(Icons.Default.Delete, contentDescription = "Delete") }
                } }
            }
        }
    }
}

@Composable
fun AddTaskDialog(urdu: Boolean, onDismiss: ()->Unit, onSave: (String,String,String,String)->Unit) {
    var title by remember { mutableStateOf("") }; var category by remember { mutableStateOf("Personal") }
    var priority by remember { mutableStateOf("Normal") }; var due by remember { mutableStateOf("") }
    val t: (String,String)->String = { a,b -> if(urdu) b else a }
    AlertDialog(onDismissRequest=onDismiss, title={ Text(t("New task","نیا کام")) }, text={
        Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(title,{title=it},label={Text(t("Task name","کام کا نام"))},singleLine=true)
            Text(t("Category","قسم"))
            Row { FilterChip(selected=category=="Personal",onClick={category="Personal"},label={Text(t("Personal","ذاتی"))}); Spacer(Modifier.width(8.dp)); FilterChip(selected=category=="Business",onClick={category="Business"},label={Text(t("Business","کاروبار"))}) }
            Text(t("Priority","اہمیت"))
            Row { listOf("Low","Normal","High").forEach { p -> FilterChip(selected=priority==p,onClick={priority=p},label={Text(t(p, when(p){"Low"->"کم";"High"->"زیادہ";else->"معمول"}))}) } }
            OutlinedTextField(due,{due=it},label={Text(t("Due date (e.g. 25 Nov)","آخری تاریخ (مثلاً 25 Nov)"))},singleLine=true)
        }
    }, confirmButton={ Button(onClick={if(title.isNotBlank()) onSave(title.trim(),category,priority,due.trim())}, enabled=title.isNotBlank()) { Text(t("Save","محفوظ کریں")) } }, dismissButton={ TextButton(onClick=onDismiss){Text(t("Cancel","منسوخ"))} })
}

@Composable
fun AddEntryDialog(urdu: Boolean, onDismiss: ()->Unit, onSave: (String,Double,Boolean)->Unit) {
    var title by remember { mutableStateOf("") }; var amount by remember { mutableStateOf("") }; var income by remember { mutableStateOf(true) }
    val t: (String,String)->String = { a,b -> if(urdu) b else a }
    AlertDialog(onDismissRequest=onDismiss, title={Text(t("Add money record","رقم کا اندراج"))}, text={
        Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(title,{title=it},label={Text(t("Description","تفصیل"))},singleLine=true)
            OutlinedTextField(amount,{amount=it},label={Text(t("Amount (PKR)","رقم (روپے)"))},singleLine=true)
            Row { FilterChip(selected=income,onClick={income=true},label={Text(t("Income","آمدن"))}); Spacer(Modifier.width(8.dp)); FilterChip(selected=!income,onClick={income=false},label={Text(t("Expense","خرچ"))}) }
        }
    }, confirmButton={ Button(onClick={amount.toDoubleOrNull()?.let { if(title.isNotBlank() && it>0) onSave(title.trim(),it,income) }}, enabled=title.isNotBlank() && (amount.toDoubleOrNull() ?: 0.0)>0) {Text(t("Save","محفوظ کریں"))} }, dismissButton={TextButton(onClick=onDismiss){Text(t("Cancel","منسوخ"))}})
}
